<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
 <div class="topborder">
            <img src="ico.jpeg" style="width:15%;height: 100%;position:absolute;left:2%;cursor: pointer" onclick="change1('index')" />
            <div class="search">
                <input type="text" id="question" style="font-size:17px;border:none;width:90%;height:90%;position:absolute;left:0%;top:0%;"/>
                <img src="search.png" style="height:75%;width:5%;position:absolute;left:93%;top:15%;cursor:pointer" onclick="query()"/>
            </div>
            
            <label style="position:absolute;top:36%;left:71%;cursor: pointer" onclick="change('index',this)">Home</label>
            <label style="position:absolute;top:36%;left:76%;cursor: pointer" onclick="change('contact_us',this)">Contact us</label>
            <label style="position:absolute;top:36%;left:85%;cursor: pointer" id="login" onclick="change('login',this)"> <?php if(isset($_SESSION["name"])){echo "<b style='color:yellow'>".$_SESSION["name"]."</b>";}else {echo 'Login';} ?></label>

            <div class="dropdown" style="border-radius:50%;height:20%;width:20%;position:absolute;left:85%;top:27%;">
                 <img src="hamburger.png" style="border-radius:55%;height:300%;width:15%;"  class="dropbtn" onclick="myFunction()"/>
                <div id="myDropdown" class="dropdown-content">
                  <a href="#">Check Complaint</a>
                  <a href="#">Update Complaint</a>
                <?php                  if (isset($_SESSION["name"])) {
                      echo '<a href="logout.php">Logout</a>';
                  }
                  ?>
                </div>
            </div>
            
        </div>