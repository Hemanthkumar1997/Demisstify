<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>


<div class="bottom" id="bt">
            <label style="color:white;position:absolute;top:80%;left:38%;">Copyright © 2018 Demisstify. All rights reserved</label>       
        </div>