<?php
session_start();
$_SESSION["type"]=filter_input(INPUT_GET, 'id');
?>
﻿<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Home</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <link rel="stylesheet" href="bootstrap.css">
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
         <script src="ajaxjquery.js"></script>
         <script src="bootstrap.js"></script>
         <style>
            
            .middle{
                 position: absolute;
                 top:13.5%;
                 left:35%;
            }
            <?php include 'common.php'; ?>
            .options{
                color:White;
                position:absolute;
                top:80%;
                height:12%;
                width:12%;
                left:30%;
                background:#4A148C;
                font-size: 20px;
                text-align:center;
                border-radius: 10px;
                cursor: pointer;
            }
            .options1{              
                color:White;
                position:absolute;
                top:80%;
                height:12%;
                width:12%;
                left:60%;
                background:#4A148C;
                font-size: 20px;
                text-align:center;
                border-radius: 10px;
                cursor:pointer;
            }
            form input{
                width:400px;
                margin:auto;
                border-radius: 10px;
                display:inline;
                margin-right: 15px;
                height:40px;
                padding-left: 15px;
                margin-top: 20px;
            }
            form input:focus,select:focus{
                outline: none;
            }
            input[type=number]{
                
                width:183px;
                margin-right: 20px;
            }
            b{
                font-size: 20px;
            }
            input[type=file]:focus{
                outline: none;
            }
        </style>
        <script>

            <?php include 'commonscripts.php'; ?>
            
            $(document).ready(function(){
                $('input[type="file"]').change(function(){
                var fn=this.value;
                var index=fn.lastIndexOf(".")+1;
                var extension=fn.substr(index,fn.length).toLowerCase();
                if(extension!=="jpg"&&extension!=="jpeg"&&extension!=="png"){
                    alert("Invalid Image type");
                    this.value=null;
                }
                });
            });
            function validate(){
                  var2=document.forms["qform"]["name"].value;
                  var3=document.forms["qform"]["cn"].value;
                  var4=document.forms["qform"]["height"].value;
                  var5=document.forms["qform"]["weight"].value;
                  var1=document.forms["qform"]["img"].value;
                  var file = document.getElementById('img').files[0];
                  if(file && file.size < 6144) { 
                      if(var1===""||var2===""||var3===""||var4===""||var5===""){
                      alert("One or more fields are empty");
                      return false;
                  }}
                  else return true;
                   
      
                  
              }
     </script>
    </head>
    <body>
        
        <?php include 'topborder.php'; ?>
        
        <div class="middle" style="z-index:-1;background: #E8EAF6;height:110%;padding:30px;border-radius:10px;" >
            <div class="Form">
                <form name="qform" action="upload.php" method="post" enctype="multipart/form-data" onsubmit="return validate()">
                    <Label style="position:relative;left:25%;font-size:25px;color:#311B92">Complaint Forum</label><br><br>
                    <input type="text" title="Enter name of missing person" name="name" placeholder="Enter Name" ><b style="color:red">*</b><br><br>
                    <select name="age" style="width:100px;height:40px;border-radius: 15px;margin-right: 15px">
                        <option value="fake" >Select Age</option>
                     <?php 
                      for ($i = 1; $i <= 100; $i++) {
                        echo "<option value='" . $i . "'>" . $i . "</option>";
                    }
                     ?>
                    </select><b style="color:red">*</b>
                    
                    <input type="number" title="Enter your contact Number" name="cn" placeholder="Enter Contact number" style="width:270px" min="6000000000" oninvalid="alert('Invalid phone number')"><b style="color:red;font-size:20px">*</b><br><br>
                    <input type="number" title="Enter height of missing person" name="height" difference="1" min="100" placeholder="Enter Height in cm"><b style="color:red">*</b>
                    <input type="number" title="Enter weight of missing person" name="weight" difference="1"  placeholder="Enter weight in kg"><b style="color:red">*</b>
                    
                    <br><br>
                    <input type="text"  title="Enter your email" name="email" placeholder="Enter Contact Email" ><b style="color:red">*</b>   <br><br>
                    <input type="text" title="Enter last seen place of missing person" name="place" placeholder="Enter Last seen place" ><b style="color:red">*</b>   <br><br>
                    <input type='file' title="upload a Clear picture of missing person" name="img" accept="image/*" oninput="validateImage()">
                    <label style='color:red'>*Image size should be less than 6MB</label>
                    <center><input type="submit" value="upload" style="font-size: 20px;background:Gold;color:#311B92;width: 200px"></center>
                </form>
            </div>
            

        </div>
        
        <?php include 'bottomborder.php'; ?>
        <script>var d=document.getElementById("bt").style;
                d.position="absolute";
                d.top="130%";</script>
    </body>
</html>
