<?php
session_start();
$_SESSION["q"]= filter_input(INPUT_GET, 'q');
$_SESSION["order"]=filter_input(INPUT_GET, 'order');
$_SESSION["set"]=filter_input(INPUT_GET, 'set');
?>
<?php
$db=new mysqli("localhost","root","","demisstify");
if($db->error){
    die("connection failed".$db->error);
}
if ($_SESSION["order"]==""||!isset($_SESSION["order"])) {
    $order = "name";
    
} else {
    $order = $_SESSION["order"];
}
$row_num=0;
$pos = 20;
$question=$_SESSION["q"];
    $start=0;
    $end=5;
     if(isset($_SESSION["set"]))
    {
        $start=((int)$_SESSION["set"])*5;
        $end=$start+5;
    }
$count_query="SELECT * FROM `missing` WHERE `name`= '$question' or `place`='$question' or `name` like '$question%' or `place` like '$question%' order by $order";
$x=$db->query($count_query);
$total=mysqli_num_rows($x);
$sql="SELECT `Complaint ID`, `name`, `age`, `height`, `weight`, `contact_number`, `contact_email`, `place` FROM `missing` WHERE `name`= '$question' or `place`='$question' or `name` like '$question%' or `place` like '$question%' order by $order LIMIT 5 OFFSET ".$start;
$result=$db->query($sql);
echo'<html><head><style>';
    include 'common.php';
    echo '
        #sortby:focus{
         outline:none;
         }
        ';
    echo '</style><script>';
    include 'commonscripts.php';
    echo 'function sort(){
            var ord=document.getElementById("sortby").value;
            if(ord!="")
            window.location.href = "search.php?q='.$question.'&order="+ord;'.'}';
    echo '</script></head><body>';
   include 'topborder.php';
if(mysqli_num_rows($result)>0){
    $count =5;
    $initial_count=0;
    if(isset($_SESSION["set"])){
        $row_num=((int)$_SESSION["set"])+1;
    }
    else{
        $row_num=1;
    }
    if (($total / $count) < 1) {
        $total = 1;
    } else {
        $total =  ((int)($total / $count))+1;
    }
    echo '<b style="z-index:-1;position:absolute;left:12%;top:15%;font-size:20px">showing '.$row_num.'/'.$total.'</b>';
    echo '<select id="sortby" name="age" style="z-index:0;position:absolute;left:75%;top:14.99%;font-size:15px;width:150px;height:25px;margin-right: 15px" onchange=sort()>
                         <option value="" >SORT BY</option>
                         <option value="name">Name</option>
                         <option value="date">Date</option>
                         <option value="place">Place</option>
                         <option value="age">Age</option>
                         </select>';
    echo '<script>document.getElementById("sortby").value="'.$order.'";</script>';
while($row=$result->fetch_assoc() and $initial_count<$count){
    echo '<div class="info" id='.$row["Complaint ID"].' style="z-index:1;background:#E8EAF6;border-radius:15px;width:75%;height:150;border:solid Gold ;z-index:-1;position:absolute;left:12%;top:'.$pos.'%;">';
            echo '<div class="name" style="position:relative;left:2%;top:10%"><b>Name:</b><b style="color:blue;">'.$row["name"]."</b></div>";
           
    echo '<img src="fetch.php?id='.$row["Complaint ID"].'" width=140 height=140 style="position:relative;top:-15px;left:85%"/>'."</div>";
    $pos=$pos+30;
    $initial_count+=1;
}
}
else 
{
    echo '<b style="color:red;position:absolute;top:48%;left:44%;font-size:25px;z-index:-1">No Entries Found</b>';
}
$db->close();
 
   if($row_num!=0){
       
   }
   echo "<b style='position:absolute;top:".($pos+5)."%;left:45%'>||";
   for($i=1;$i<=$total;$i++){
       if($i!=$total){echo $i."|";}
       else{
           echo $i;
       }
    }
    echo "||</b>";
    include 'bottomborder.php';
    if($pos==20){$pos=70;}
    echo '<script>var d=document.getElementById("bt").style;
                d.position="absolute";
                d.top="'.($pos+20).'%";</script>';
    
        echo '</body></html>';