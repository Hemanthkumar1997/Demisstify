<?php
session_start();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * 
 */
?>
<?php
$name= filter_input(INPUT_POST, "name");
$contact=filter_input(INPUT_POST,"cn");
$height=filter_input(INPUT_POST,"height");
$weight=filter_input(INPUT_POST,"weight");
$email=filter_input(INPUT_POST,"email");
$place=filter_input(INPUT_POST,"place");
$photo=filter_input(INPUT_POST,"img");
$ID="DMS".substr($name,0,4).substr($contact, 8);
$age=intval(filter_input(INPUT_POST,"age"));
$type=$_SESSION["type"];
$db=new mysqli("localhost","root","","demisstify");
    if($db->connect_error){
        die("Connection failed: " .$db->connect_error);
    }
    else{
        $imagename=$_FILES["img"]["name"]; 

        $imagetmp=addslashes (file_get_contents($_FILES['img']['tmp_name']));
        $sql="INSERT INTO `missing`(`Complaint ID`, `name`, `age`, `height`, `weight`, `contact_number`, `contact_email`, `place`, `photo`, `type`) VALUES ('$ID','$name','$age','$height','$weight','$contact','$email','$place','$imagetmp','$type')";
        if(!$db->query($sql)===TRUE){
            echo $db->error;
        }else{
           Echo '<p style="color:blue;font-size:25px;position:absolute;left:20%;top:42%;">successfully Registered Complaint.We will get to you as soon as we find the match </p>';
                
                    header("Refresh:0 url=FMissing?id=missing");
        }
      
        $db->close();
    }